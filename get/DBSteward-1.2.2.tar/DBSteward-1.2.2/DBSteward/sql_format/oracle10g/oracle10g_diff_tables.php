<?php
/**
 * Diffs tables.
 *
 * @package DBSteward
 * @subpackage oracle10g
 * @license http://www.opensource.org/licenses/bsd-license.php Simplified BSD License
 * @author Nicholas J Kiraly <kiraly.nicholas@gmail.com>
 */

class oracle10g_diff_tables extends pgsql8_diff_tables {

}

?>
