<?php
/**
 * Diffs sequences.
 *
 * @package DBSteward
 * @subpackage mysql4
 * @license http://www.opensource.org/licenses/bsd-license.php Simplified BSD License
 * @author Nicholas J Kiraly <kiraly.nicholas@gmail.com>
 */

class mysql4_diff_sequences {

}

?>
